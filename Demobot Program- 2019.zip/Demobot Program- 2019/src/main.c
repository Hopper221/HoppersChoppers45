#include <kipr/botball.h>

int main()
{
    shut_down_in(119); // We only have 2 minutes to run program
    printf("GO!\n");
    
    enable_servos();
    set_servo_position(0,300); // starting arm position
    set_servo_position(3,100);
    msleep(400);
    
    mav(0,0); //turn slightly to get block
    mav(3,-1000);
    msleep(140);
    
    mav(0,-1000); //moves forward and captures block
    mav(3,-1000);
    msleep(750);
    
    mav(0,0); //turns left to face rectangle cube
    mav(3,-1000);
    msleep(1600);
    
    mav(3,-1000); //moves torward rectangle cube
    mav(0,-1000);
    msleep(4700);
    
    mav(0,0); //pushes stuff in box
    mav(3,-1000);
    msleep(200);
    
    mav(0,1000);
    mav(3,1000);
    msleep(2300);
    
    mav(3,-500); 
    mav(0,500);
    msleep(1506);
    
    mav(0,1000);
    mav(3,1000);
    msleep(3200);
    
    set_servo_position(0,1760);
    set_servo_position(3,700);
    msleep(400);
    
    mav(0,1000);
    mav(3,1000);
    msleep(900);
    
    set_servo_position(0,1760);
    set_servo_position(3,72);
    msleep(500);
    
    mav(0,-1000);
    mav(3,-1000);
    msleep(7000);
    
    mav(3,1000);
    mav(0,000);
    msleep(1500);    
    
    mav(0,1000);
    mav(3,1000);
    msleep(400);
    
    set_servo_position(3,1500);
    
    disable_servos();
    return 0;
}
