#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    motor(0,1000);
    msleep(1130);
    return 0;
}
