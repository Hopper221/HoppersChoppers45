#include <kipr/botball.h>
int p=0; //variables
int p1=3;
int u=600;
int d=1700;
int o=1300;
int c=0;
int f()
{
motor(0,1000);
motor(3,1000);
    return 0;
}
int b()
{
motor(0,-1000);
motor(3,-1000);
return 0;
}
int l()
{
motor(0,1000);
    msleep(1130);
    return 0;
}
int r()
{
motor(3,1000);
    msleep(1130);
    return 0;
}
int s(z,y) //function
{
 set_servo_position(z,y);
    return 0;
}
int main()
{
    printf("Hello World\n");
    return 0;
}
