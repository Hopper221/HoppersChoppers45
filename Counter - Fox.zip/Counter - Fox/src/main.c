#include <kipr/botball.h>
int counter=0;
int main()
{   
    printf("Hello World\n");
    enable_servos();
    set_servo_position(0,counter);
    while(counter<2000)
    {
        msleep(300);
        counter=counter+100;
            set_servo_position(0,counter);
    }
    return 0;
}
