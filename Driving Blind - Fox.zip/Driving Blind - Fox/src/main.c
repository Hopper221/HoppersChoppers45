#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    while(0==0)
    {
        mav(0,1500);
        mav(3,1500);
     if(analog(0)>=1500)
     {
        mav(0,-1500);
        mav(3,-60);
     }
    }
    return 0;
}
